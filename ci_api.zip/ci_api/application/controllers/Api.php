<?php
   
require APPPATH . 'libraries/REST_Controller.php';
     
class Api extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }

    public function save_post(){
      $id = $this->input->post("id");
       $name = $this->input->post("name");
       $mobileno = $this->input->post("mobileno");
       $address = $this->input->post("address");
       $field = array(
         'name'=>$name,
         'mobileno'=>$mobileno,
         'address'=>$address,
      );
      if($id == 0)
         $this->db->insert('students', $field);
      else{
         $this->db->where('id', $id);
         $this->db->update('students', $field);
      }

      $dataarray = array();
      $dataarray["status"] = "success";
      header('Content-Type: application/json');
      echo json_encode(array("data" => $dataarray));
    }

   public function list_post(){
      $query = "SELECT * FROM students";
		$result = $this->db->query($query);
		$data["lists"] = $result->result();
      $this->response($data, 200);
   }

   public function delete_post(){
      $id = $this->input->post("id");

      $query = "DELETE FROM students WHERE id = " . $id;
		$this->db->query($query);

      $dataarray = array();
      $dataarray["status"] = "success";
      header('Content-Type: application/json');
      echo json_encode(array("data" => $dataarray));
		
   }
}